"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/votings";
exports.ids = ["pages/api/votings"];
exports.modules = {

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "(api)/./models/Voting.js":
/*!**************************!*\
  !*** ./models/Voting.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst votingSchema = mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema({\n    ketua: {\n        type: String,\n        required: true\n    },\n    wakil: {\n        type: String,\n        required: true\n    },\n    visi: {\n        type: String,\n        required: true\n    },\n    misi: {\n        type: String,\n        required: true\n    },\n    thumbnail: {\n        type: String,\n        required: true\n    },\n    currentVotes: {\n        type: Number,\n        default: 0\n    },\n    voter: {\n        type: [\n            String\n        ],\n        default: []\n    }\n});\nconst Voting = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Voting) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model(\"Voting\", votingSchema);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Voting);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9tb2RlbHMvVm90aW5nLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUErQjtBQUUvQixNQUFNQyxlQUFlRCxzREFBZSxDQUFDO0lBQ25DRyxPQUFPO1FBQ0xDLE1BQU1DO1FBQ05DLFVBQVUsSUFBSTtJQUNoQjtJQUNBQyxPQUFPO1FBQ0xILE1BQU1DO1FBQ05DLFVBQVUsSUFBSTtJQUNoQjtJQUNBRSxNQUFNO1FBQ0pKLE1BQU1DO1FBQ05DLFVBQVUsSUFBSTtJQUNoQjtJQUNBRyxNQUFNO1FBQ0pMLE1BQU1DO1FBQ05DLFVBQVUsSUFBSTtJQUNoQjtJQUNBSSxXQUFXO1FBQ1ROLE1BQU1DO1FBQ05DLFVBQVUsSUFBSTtJQUNoQjtJQUNBSyxjQUFjO1FBQ1pQLE1BQU1RO1FBQ05DLFNBQVM7SUFDWDtJQUNBQyxPQUFPO1FBQ0xWLE1BQU07WUFBQ0M7U0FBTztRQUNkUSxTQUFTLEVBQUU7SUFDYjtBQUNGO0FBRUEsTUFBTUUsU0FBU2YsK0RBQXNCLElBQUlBLHFEQUFjLENBQUMsVUFBVUM7QUFFbEUsaUVBQWVjLE1BQU1BLEVBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ldm9uc3kvLi9tb2RlbHMvVm90aW5nLmpzPzkyYzUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG1vbmdvb3NlIGZyb20gXCJtb25nb29zZVwiXHJcblxyXG5jb25zdCB2b3RpbmdTY2hlbWEgPSBtb25nb29zZS5TY2hlbWEoe1xyXG4gIGtldHVhOiB7XHJcbiAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICByZXF1aXJlZDogdHJ1ZSxcclxuICB9LFxyXG4gIHdha2lsOiB7XHJcbiAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICByZXF1aXJlZDogdHJ1ZSxcclxuICB9LFxyXG4gIHZpc2k6IHtcclxuICAgIHR5cGU6IFN0cmluZyxcclxuICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gIH0sXHJcbiAgbWlzaToge1xyXG4gICAgdHlwZTogU3RyaW5nLFxyXG4gICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgfSxcclxuICB0aHVtYm5haWw6IHtcclxuICAgIHR5cGU6IFN0cmluZyxcclxuICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gIH0sXHJcbiAgY3VycmVudFZvdGVzOiB7XHJcbiAgICB0eXBlOiBOdW1iZXIsXHJcbiAgICBkZWZhdWx0OiAwLFxyXG4gIH0sXHJcbiAgdm90ZXI6IHtcclxuICAgIHR5cGU6IFtTdHJpbmddLFxyXG4gICAgZGVmYXVsdDogW10sXHJcbiAgfSxcclxufSlcclxuXHJcbmNvbnN0IFZvdGluZyA9IG1vbmdvb3NlLm1vZGVscy5Wb3RpbmcgfHwgbW9uZ29vc2UubW9kZWwoXCJWb3RpbmdcIiwgdm90aW5nU2NoZW1hKVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgVm90aW5nXHJcbiJdLCJuYW1lcyI6WyJtb25nb29zZSIsInZvdGluZ1NjaGVtYSIsIlNjaGVtYSIsImtldHVhIiwidHlwZSIsIlN0cmluZyIsInJlcXVpcmVkIiwid2FraWwiLCJ2aXNpIiwibWlzaSIsInRodW1ibmFpbCIsImN1cnJlbnRWb3RlcyIsIk51bWJlciIsImRlZmF1bHQiLCJ2b3RlciIsIlZvdGluZyIsIm1vZGVscyIsIm1vZGVsIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./models/Voting.js\n");

/***/ }),

/***/ "(api)/./pages/api/votings/index.js":
/*!************************************!*\
  !*** ./pages/api/votings/index.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _utils_mongoConnection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../utils/mongoConnection */ \"(api)/./utils/mongoConnection.js\");\n/* harmony import */ var _models_Voting__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../models/Voting */ \"(api)/./models/Voting.js\");\n\n\nasync function getCandidatesForVotings(req, res) {\n    await (0,_utils_mongoConnection__WEBPACK_IMPORTED_MODULE_0__[\"default\"])();\n    if (req.method !== \"GET\") return res.status(405).json({\n        message: \"Method not allowed\"\n    });\n    try {\n        const candidatesForVotings = await _models_Voting__WEBPACK_IMPORTED_MODULE_1__[\"default\"].find();\n        res.json({\n            candidatesForVotings\n        });\n    } catch (error) {\n        console.log(error);\n    }\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getCandidatesForVotings);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvdm90aW5ncy9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBMkQ7QUFDaEI7QUFFM0MsZUFBZUUsd0JBQXdCQyxHQUFHLEVBQUVDLEdBQUcsRUFBRTtJQUMvQyxNQUFNSixrRUFBY0E7SUFFcEIsSUFBSUcsSUFBSUUsTUFBTSxLQUFLLE9BQ2pCLE9BQU9ELElBQUlFLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7UUFBRUMsU0FBUztJQUFxQjtJQUU5RCxJQUFJO1FBQ0YsTUFBTUMsdUJBQXVCLE1BQU1SLDJEQUFXO1FBRTlDRyxJQUFJRyxJQUFJLENBQUM7WUFBRUU7UUFBcUI7SUFDbEMsRUFBRSxPQUFPRSxPQUFPO1FBQ2RDLFFBQVFDLEdBQUcsQ0FBQ0Y7SUFDZDtBQUNGO0FBRUEsaUVBQWVULHVCQUF1QkEsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovL2V2b25zeS8uL3BhZ2VzL2FwaS92b3RpbmdzL2luZGV4LmpzPzk5ZjkiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG1vbmdvRGJDb25uZWN0IGZyb20gXCIuLi8uLi8uLi91dGlscy9tb25nb0Nvbm5lY3Rpb25cIlxyXG5pbXBvcnQgVm90aW5nIGZyb20gXCIuLi8uLi8uLi9tb2RlbHMvVm90aW5nXCJcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldENhbmRpZGF0ZXNGb3JWb3RpbmdzKHJlcSwgcmVzKSB7XHJcbiAgYXdhaXQgbW9uZ29EYkNvbm5lY3QoKVxyXG5cclxuICBpZiAocmVxLm1ldGhvZCAhPT0gXCJHRVRcIilcclxuICAgIHJldHVybiByZXMuc3RhdHVzKDQwNSkuanNvbih7IG1lc3NhZ2U6IFwiTWV0aG9kIG5vdCBhbGxvd2VkXCIgfSlcclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGNhbmRpZGF0ZXNGb3JWb3RpbmdzID0gYXdhaXQgVm90aW5nLmZpbmQoKVxyXG5cclxuICAgIHJlcy5qc29uKHsgY2FuZGlkYXRlc0ZvclZvdGluZ3MgfSlcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5sb2coZXJyb3IpXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBnZXRDYW5kaWRhdGVzRm9yVm90aW5nc1xyXG4iXSwibmFtZXMiOlsibW9uZ29EYkNvbm5lY3QiLCJWb3RpbmciLCJnZXRDYW5kaWRhdGVzRm9yVm90aW5ncyIsInJlcSIsInJlcyIsIm1ldGhvZCIsInN0YXR1cyIsImpzb24iLCJtZXNzYWdlIiwiY2FuZGlkYXRlc0ZvclZvdGluZ3MiLCJmaW5kIiwiZXJyb3IiLCJjb25zb2xlIiwibG9nIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/votings/index.js\n");

/***/ }),

/***/ "(api)/./utils/mongoConnection.js":
/*!**********************************!*\
  !*** ./utils/mongoConnection.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ mongoDbConnect)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n/* This is a database connection function*/ \nconst connection = {} /* creating connection object*/ ;\nasync function mongoDbConnect() {\n    /* check if we have connection to our databse*/ if (connection.isConnected) return;\n    /* connecting to our database */ const db = await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGODB_URI);\n    connection.isConnected = db.connections[0].readyState;\n    console.log(`MongoDB Connected on host: ${db.connection.host}`);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi91dGlscy9tb25nb0Nvbm5lY3Rpb24uanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEseUNBQXlDLEdBQ1Y7QUFFL0IsTUFBTUMsYUFBYSxDQUFDLEVBQUUsNkJBQTZCO0FBRXBDLGVBQWVDLGlCQUFpQjtJQUM3Qyw2Q0FBNkMsR0FDN0MsSUFBSUQsV0FBV0UsV0FBVyxFQUFFO0lBRTVCLDhCQUE4QixHQUM5QixNQUFNQyxLQUFLLE1BQU1KLHVEQUFnQixDQUFDTSxRQUFRQyxHQUFHLENBQUNDLFdBQVc7SUFFekRQLFdBQVdFLFdBQVcsR0FBR0MsR0FBR0ssV0FBVyxDQUFDLEVBQUUsQ0FBQ0MsVUFBVTtJQUVyREMsUUFBUUMsR0FBRyxDQUFDLENBQUMsMkJBQTJCLEVBQUVSLEdBQUdILFVBQVUsQ0FBQ1ksSUFBSSxDQUFDLENBQUM7QUFDaEUsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2V2b25zeS8uL3V0aWxzL21vbmdvQ29ubmVjdGlvbi5qcz8zZWVjIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIFRoaXMgaXMgYSBkYXRhYmFzZSBjb25uZWN0aW9uIGZ1bmN0aW9uKi9cclxuaW1wb3J0IG1vbmdvb3NlIGZyb20gXCJtb25nb29zZVwiXHJcblxyXG5jb25zdCBjb25uZWN0aW9uID0ge30gLyogY3JlYXRpbmcgY29ubmVjdGlvbiBvYmplY3QqL1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gbW9uZ29EYkNvbm5lY3QoKSB7XHJcbiAgLyogY2hlY2sgaWYgd2UgaGF2ZSBjb25uZWN0aW9uIHRvIG91ciBkYXRhYnNlKi9cclxuICBpZiAoY29ubmVjdGlvbi5pc0Nvbm5lY3RlZCkgcmV0dXJuXHJcblxyXG4gIC8qIGNvbm5lY3RpbmcgdG8gb3VyIGRhdGFiYXNlICovXHJcbiAgY29uc3QgZGIgPSBhd2FpdCBtb25nb29zZS5jb25uZWN0KHByb2Nlc3MuZW52Lk1PTkdPREJfVVJJKVxyXG5cclxuICBjb25uZWN0aW9uLmlzQ29ubmVjdGVkID0gZGIuY29ubmVjdGlvbnNbMF0ucmVhZHlTdGF0ZVxyXG5cclxuICBjb25zb2xlLmxvZyhgTW9uZ29EQiBDb25uZWN0ZWQgb24gaG9zdDogJHtkYi5jb25uZWN0aW9uLmhvc3R9YClcclxufVxyXG4iXSwibmFtZXMiOlsibW9uZ29vc2UiLCJjb25uZWN0aW9uIiwibW9uZ29EYkNvbm5lY3QiLCJpc0Nvbm5lY3RlZCIsImRiIiwiY29ubmVjdCIsInByb2Nlc3MiLCJlbnYiLCJNT05HT0RCX1VSSSIsImNvbm5lY3Rpb25zIiwicmVhZHlTdGF0ZSIsImNvbnNvbGUiLCJsb2ciLCJob3N0Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./utils/mongoConnection.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/votings/index.js"));
module.exports = __webpack_exports__;

})();