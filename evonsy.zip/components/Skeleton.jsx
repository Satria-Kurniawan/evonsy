const Skeleton = () => {
  return <div>Skeleton</div>
}

export default Skeleton
