const Waiting = () => {
  return (
    <div className="max-w-[4rem]">
      <img src="/waiting.svg" width={400} />
    </div>
  )
}

export default Waiting
