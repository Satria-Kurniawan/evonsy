export default function DashboardPage() {
  return <div>Dashboard</div>
}

DashboardPage.getAdminLayout = function (page) {
  return <>{page}</>
}
